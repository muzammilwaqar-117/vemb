const express  = require("express");
//const bcrypt = require("bcrypt");
//const jwt = require("jsonwebtoken");

const UserController = require("../controllers/user");

const router = express.Router();


//const { error } = require("console");
//const user = require("../models/user");


//sign up post router
router.post("/signup",UserController.createUser);


//login post router
router.post("/login",UserController.userLogin);


module.exports = router;
