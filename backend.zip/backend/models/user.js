const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');
const userSchema = mongoose.Schema({
  fullName: { type:String, required:true },
  email: { type:String, required: true, unique: true },
  password: { type:String, required:true },
  phoneNumber: { type:String, required:true },
  fullAddress: { type:String, required:true },
  cnicNumber: { type:String, required:true },
  //imagePath : { type:String, required:true },
  accountStatus: { type:String, required:true }
});

userSchema.plugin(uniqueValidator);

module.exports = mongoose.model('User',userSchema);
